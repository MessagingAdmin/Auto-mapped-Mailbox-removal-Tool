[System.Reflection.Assembly]::LoadWithPartialName('presentationframework') | out-null

$ConfigurationData = Import-Clixml .\config.xml
$ScriptPath = $ConfigurationData.ScriptPath
$ResourcePath = $ConfigurationData.ResourcePath


foreach ($Assembly in (Get-ChildItem $ResourcePath -Filter *.dll)) {
    [System.Reflection.Assembly]::LoadFrom($Assembly.fullName) | Out-Null
}
If (Get-Module AutoMappingRemovalTool) {
    Remove-Module AutoMappingRemovalTool
}
Import-Module (Join-Path -Path $ScriptPath -ChildPath "\AutoMappingRemovalTool.psm1")


function LoadXml ($global:filename) {
    $XamlLoader = (New-Object System.Xml.XmlDocument)
    $XamlLoader.Load($filename)
    return $XamlLoader
}

$FileName = Join-Path -Path $ScriptPath -ChildPath "\MainWindow.xaml"
$XamlMainWindow = LoadXml("$FileName")

$Reader = (New-Object System.Xml.XmlNodeReader $XamlMainWindow)
$Global:Form = [Windows.Markup.XamlReader]::Load($Reader)

$XamlMainWindow.SelectNodes("//*[@*[contains(translate(name(.),'n','N'),'Name')]]")  | ForEach-Object { 
    New-Variable  -Name $_.Name -Value $Form.FindName($_.Name) -Force -Scope Global
}


$TXT_UserEmail.add_KeyDown{
    if ($_.Key -eq "return") {
        Show-AutoMappedMailboxes
    }
}
$BTN_Show.add_Click{Show-AutoMappedMailboxes($BTN_Show)}
$BTN_Remove.add_Click{Remove-AutoMappedMailboxes($BTN_Remove)}
#$BTN_Remove.add_Click{Remove-Mailboxes($BTN_Remove)}

$BTN_Help.add_Click{
    $AboutFlyout.Theme = "Accent"
    $AboutFlyout.iSopen = "$true"
}
$LBL_Copy.add_Mousedown{
    Set-Clipboard -Value "Auto-Mapped Mailboxes"
    $LST_Mailboxes.Items | % { 
        $DisplayName = $_.Col_DisplayName
        $EmailID = $_.Col_EmailAddress
        Set-Clipboard -Value ("Display Name: $DisplayName") -Append
        Set-Clipboard -Value ("Email ID: $EmailID") -Append
    }    
}   
$LBL_Clear.add_Mousedown{
    $TXT_UserEmail.Text = ""
    $LST_Mailboxes.Items.Clear()
}
$HLK_UserGuide.add_Click{
    Start-Process "$ResourcePath\AMRT-UserGuide.pdf"
}
$Form.add_contentRendered{
    $TXT_UserEmail.focus()
    $TXT_UserEmail.Text = ""
      
    $Global:Form.Icon = Join-Path -Path $ResourcePath -ChildPath "\office365logo_uSa_icon.ico"
}

$Form.add_Closing{
    $ClosingChoice = Confirm-Action -message "Are you sure you want to exit the application?"
    If ($ClosingChoice -eq "Negative") {
        $_.Cancel = $true
        return 0
    }
}

$Form.ShowDialog() | Out-Null