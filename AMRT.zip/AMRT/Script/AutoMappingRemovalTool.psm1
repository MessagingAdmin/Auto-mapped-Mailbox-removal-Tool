###
Function Show-Error {
    param(
        [parameter(Mandatory = $true)]
        [string]
        $ScriptError
    )
    $Dialogsettings = [MahApps.Metro.Controls.Dialogs.MetroDialogSettings]::new()
    $Dialogsettings.ColorScheme = [MahApps.Metro.Controls.Dialogs.MetroDialogColorScheme]::Accented
    $ok = [MahApps.Metro.Controls.Dialogs.MessageDialogStyle]::Affirmative
    [MahApps.Metro.Controls.Dialogs.DialogManager]::ShowModalMessageExternal($Form, "Error", $ScriptError,$ok,$Dialogsettings)
}
Function Get-OperatorCredential {
    $InputOpt = [MahApps.Metro.Controls.Dialogs.LoginDialogSettings]::new()
    $InputOpt.ColorScheme = [MahApps.Metro.Controls.Dialogs.MetroDialogColorScheme]::Accented
    $InputOpt.InitialUserName = ""
    $InputOpt.AffirmativeButtonText = "Ok"
    $InputOpt.NegativeButtonVisibility = 'Visible'
    $InputOpt.NegativeButtonText = "Cancel"
    $LoginInput = [MahApps.Metro.Controls.Dialogs.DialogManager]::ShowModalLoginExternal($Form, "Login", "Enter your Email id and password", $InputOpt)
    Try {
        $OpCreds = New-Object System.Management.Automation.PSCredential($LoginInput.UserName, $LoginInput.SecurePassword)
        Return $OpCreds
    }
    Catch {
        return 1
    }    
}
Function Get-AutoMappedMailboxes {
    param(
        # Accepts user email address
        [Parameter(Mandatory = $true,
            Position = 0)]
        [string]
        $SMTPAddress,
        # Accept credentials of the requestor
        [Parameter(Mandatory = $true,
            Position = 1)]
        [system.management.automation.PSCredential]
        $Credential
    )
    $AutoDiscoverRequest = @"
        <soap:Envelope xmlns:a="http://schemas.microsoft.com/exchange/2010/Autodiscover" 
                xmlns:wsa="http://www.w3.org/2005/08/addressing" 
                xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" 
                xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
          <soap:Header>
            <a:RequestedServerVersion>Exchange2013</a:RequestedServerVersion>
            <wsa:Action>http://schemas.microsoft.com/exchange/2010/Autodiscover/Autodiscover/GetUserSettings</wsa:Action>
            <wsa:To>https://autodiscover.exchange.microsoft.com/autodiscover/autodiscover.svc</wsa:To>
          </soap:Header>
          <soap:Body>
            <a:GetUserSettingsRequestMessage xmlns:a="http://schemas.microsoft.com/exchange/2010/Autodiscover">
              <a:Request>
                <a:Users>
                  <a:User>
                    <a:Mailbox>$SMTPAddress</a:Mailbox>
                  </a:User>
                </a:Users>
                <a:RequestedSettings>
                  <a:Setting>UserDisplayName</a:Setting>
                  <a:Setting>UserDN</a:Setting>
                  <a:Setting>UserDeploymentId</a:Setting>
                  <a:Setting>MailboxDN</a:Setting>
                  <a:Setting>AlternateMailboxes</a:Setting>
                </a:RequestedSettings>
              </a:Request>
            </a:GetUserSettingsRequestMessage>
          </soap:Body>
        </soap:Envelope>
"@
    try {    
        $WebResponse = Invoke-WebRequest https://autodiscover-s.outlook.com/autodiscover/autodiscover.svc -Credential $Credential -Method Post -Body $AutoDiscoverRequest -ContentType 'text/xml; charset=utf-8'
    }
    catch {
        Show-Error "Invalid user email id or login credentials"
        return 1
    }
    [System.Xml.XmlDocument]$XMLResponse = $WebResponse.Content
    $RequestedSettings = $XMLResponse.Envelope.Body.GetUserSettingsResponseMessage.Response.UserResponses.UserResponse.UserSettings.UserSetting
    return $RequestedSettings.AlternateMailboxes.AlternateMailbox
}
Function Update-ListView {
    param(
        [parameter(Mandatory = $true)]
        [psobject[]]
        $List
    )
    foreach ($item in $List) {
        $itemobject = New-Object PSCustomObject -Property @{
            Col_DisplayName  = $item.DisplayName
            Col_EmailAddress = $item.SMTPAddress
        }
        $LST_Mailboxes.Items.Add($itemobject) | Out-Null
    }
}
Function Confirm-Action {
    param(
        [string] $message
    )
    $Dialogsettings = [MahApps.Metro.Controls.Dialogs.MetroDialogSettings]::new()
    $Dialogsettings.ColorScheme = [MahApps.Metro.Controls.Dialogs.MetroDialogColorScheme]::Accented
    $ok = [MahApps.Metro.Controls.Dialogs.MessageDialogStyle]::AffirmativeAndNegative
    $Dialogsettings.AffirmativeButtonText ="Yes"
    $Dialogsettings.NegativeButtonText ="No"
    $choice = [MahApps.Metro.Controls.Dialogs.DialogManager]::ShowModalMessageExternal($Form, "Confirm", $message, $ok, $DialogSettings)
    return $choice
}
Function Show-AutoMappedMailboxes($object) {
    If ($LST_Mailboxes.Items.Count -gt 0) {
        $LST_Mailboxes.Items.Clear()
    }
    If($TXT_UserEmail.Text -notlike "*@*.com"){
        Show-Error "User email address not in correct format. Please enter correct email address"
        return 1
    }
    $Script:OperatorCredential = Get-OperatorCredential
    If ($Script:OperatorCredential -eq 1) {
        Show-Error "No login credentials provided"
        return 1
    }
    $AutoMappedMailboxList = Get-AutoMappedMailboxes -SMTPAddress $TXT_UserEmail.Text -Credential $Script:OperatorCredential
    If ($AutoMappedMailboxList -eq 1) {
        return 1
    }
    $MailboxList = @()
    Foreach ($mailbox in $AutoMappedMailboxList) {
        $MailboxList += $mailbox.SMTPAddress
    }
    If ($MailboxList -ne "") {
        $MailboxList = $MailboxList -join (";")
    } 
    Else {
        $MailboxList = 0
        Show-Error "No auto-mapped mailboxes found"
    }     

    If ($MailboxList -eq 0) {
        return 1
    }    
    Update-ListView -List $AutoMappedMailboxList
}
Function Remove-AutoMappedMailboxes($object) {
    $SelectedMailboxes = $LST_Mailboxes.SelectedItems
    If ($SelectedMailboxes.Count -eq 0) {
        Show-Error "No mailboxes selected for removal"
        return 1
    }
    $MailboxList = @()
    foreach ($mailbox in $SelectedMailboxes) {
        $MailboxList += $mailbox.Col_EmailAddress
    }
    #$MailboxList = $MailboxList -join (";")
    $Confirmchoice = Confirm-Action -message ("Are you sure that you want to remove below mailboxes? `n " + ($MailboxList -join ("`n")))
    If ($Confirmchoice -eq "Affirmative") {
        If ((Connect-ExOnline -Credential $Script:OperatorCredential) -eq "Connection Failed") {
            Show-Error "Error in connecting to Exchange Online"
            Get-Date + "Error connecting in Office 365" | Out-File .\ConnectionError.log -Append
            $Error[0] | Out-File .\ConnectionError.log -Append
            return 0
        }
        foreach ($smtp in $MailboxList) {
            
            try {
                Remove-MailboxPermission -identity $smtp -user $TXT_UserEmail.Text -AccessRights FULLACCESS -confirm:$false
                Add-MailboxPermission -identity $smtp -user $TXT_UserEmail.Text -AccessRights FULLACCESS -Automapping:$false | Out-Null
            }
            catch {
                Show-Error "Error in updating permissions for $smtp"
                return 1
            }
        }
        $Dialogsettings = [MahApps.Metro.Controls.Dialogs.MetroDialogSettings]::new()
        $Dialogsettings.ColorScheme = [MahApps.Metro.Controls.Dialogs.MetroDialogColorScheme]::Accented
        $ok = [MahApps.Metro.Controls.Dialogs.MessageDialogStyle]::Affirmative
        $message = "Your request for removing automapped mailboxes has been completed"
        [MahApps.Metro.Controls.Dialogs.DialogManager]::ShowModalMessageExternal($Form, "Complete", $message, $ok, $Dialogsettings)        
    }
}


Function Connect-ExOnline {

    [CmdletBinding()]
    Param(
        # Setting up session requirements
        [PSCredential]$Credential
    )
    $SessOpt = New-PSSessionOption -SkipCACheck -SkipCNCheck -SkipRevocationCheck -ProxyAccessType IEConfig
    $URI = "https://outlook.office365.com/powershell-liveid/"
    Try {
          $Session = New-PSSession -ConfigurationName Microsoft.Exchange -ConnectionUri $URI -Credential $Credential -SessionOption $SessOpt -allowredirection -Authentication Basic -ErrorAction Stop
    }
    Catch {
            return "Connection Failed"
    }

    Import-Module (Import-PSSession $Session -AllowClobber -DisableNameChecking) -DisableNameChecking -Global | Out-Null
} 
